# run_source_html

Dùng để chạy source đã được build để test hoặc thử nghiệm hoặc để chạy trong nội bộ

## Các bước để chạy được:

- Copy source build vào build folder
  - Lưu ý: Phải có index.html ở bản build đó
- Mở terminal ở thư mục run_source_html
- Chạy lệnh:
  python3

```bash
python3 server.py
```

python

```bash
python server.py
```

- Mở trình duyệt web của bạn và truy cập: [http://localhost:8000](http://localhost:8000)

##
