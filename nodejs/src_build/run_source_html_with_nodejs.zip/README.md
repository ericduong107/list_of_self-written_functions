# run_source_html

Dùng để chạy source đã được build để test hoặc thử nghiệm hoặc để chạy trong nội bộ

## Các bước để chạy được:

- Copy source build vào build folder
  - Lưu ý: Phải có index.html ở bản build đó
- Mở terminal ở thư mục run_source_html
- Chạy lệnh:
```bash
npm start
// Hoặc
node server.js
```

- Mở trình duyệt web của bạn và truy cập: [http://localhost:3000](http://localhost:3000)

##
